# rust.fun
Messing around with Rust in R
